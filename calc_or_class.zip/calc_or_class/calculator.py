from tkinter import *
from tkinter import ttk

# balika4222

root = Tk()
root.title("Km/h Calc")
root.geometry("300x200")
root.resizable(False, False)
root.config(bg="grey")
root.iconbitmap("favicon.ico")

sys_bg = PhotoImage(file="bg.png")
km = 0
h = 0
m = 0

km_s = StringVar()
time_s = StringVar()
time_mode = StringVar()

def calc():
    global km, h, m
    try:
        km = float(km_s.get())
        time = float(time_s.get())
        mode = str(time_mode.get())
        
        if mode == "h":
            hourtomin = time * 60
            speedcalc = km / time 
            minfinal = "{} percig ment, {:.2f} km/h sebességgel.".format(hourtomin, speedcalc)  # ha HOUR van kiválasztva
    
        elif mode == "m":
            tohour = time / 60
            speedcalc = km / tohour
            minfinal = "{} percig ment, {:.2f} km/h sebességgel.".format(time, speedcalc)  # ha MINUTE van kiválasztva

        outputterminutes.config(text=str(minfinal))
        outputterminutes.pack()
    
    except ZeroDivisionError:
        outputterminutes.config(text="Hibás Érték") # 0-val való osztási hiba
        outputterminutes.pack() 
    
    except ValueError:
        outputterminutes.config(text="Hibás Érték") # helytelen érték
        outputterminutes.pack()      
    
Label(root, image=sys_bg).place(x=-2, y=-2)

Label(root, text="km: ", bg="#d2dadd").place(x=90, y=5)
kmselect = Entry(root, textvariable=km_s, width=10).pack(pady=5)

hourselect = Entry(root, textvariable=time_s, width=10).pack(pady=5)
timeselect = ttk.Combobox(root, textvariable=time_mode, width=2, state="readonly", values=("h", "m"))
timeselect.place(x=80, y=33)
timeselect.current(0)

Button(root, text="calculate", font=("roboto", 15), bg="lime", activebackground="green", command=calc).pack(pady=20)

outputterminutes = Label(root, bg="white", fg="red")

root.mainloop()